<?php $this->load->view($this->foldername.'/template/header'); ?>

      

<?php $this->load->view($this->foldername.'/template/footer'); ?>