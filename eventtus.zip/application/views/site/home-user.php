<?php $this->load->view($this->foldername.'/template/header'); ?>

<div class="row" id="home_loggedin">
	
</div><!-- #home.row -->

<?php $this->load->view($this->foldername.'/template/footer'); ?>